package com.college.digitalsignature;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.HexFormat;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class SignatureController {

    // Creates an RSA key pair. The private key is returned only once to the browser.
    @PostMapping("/keys")
    public Map<String, String> generateKeys() throws GeneralSecurityException {
        KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
        generator.initialize(2048);
        KeyPair pair = generator.generateKeyPair();

        return Map.of(
                "privateKey", Base64.getEncoder().encodeToString(pair.getPrivate().getEncoded()),
                "publicKey", Base64.getEncoder().encodeToString(pair.getPublic().getEncoded()),
                "algorithm", "RSA-2048"
        );
    }

    // Signs the exact bytes of the uploaded file using SHA256withRSA.
    @PostMapping(value = "/sign", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Map<String, String> signFile(
            @RequestPart("file") MultipartFile file,
            @RequestParam("privateKey") String privateKeyText) throws Exception {

        if (file.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Please choose a file.");
        }

        byte[] privateKeyBytes = decodeBase64(privateKeyText, "private key");
        PrivateKey privateKey = KeyFactory.getInstance("RSA")
                .generatePrivate(new PKCS8EncodedKeySpec(privateKeyBytes));

        byte[] fileBytes = file.getBytes();

        Signature signer = Signature.getInstance("SHA256withRSA");
        signer.initSign(privateKey);
        signer.update(fileBytes);
        byte[] signatureBytes = signer.sign();

        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        String hash = HexFormat.of().formatHex(digest.digest(fileBytes));

        return Map.of(
                "fileName", safeFileName(file.getOriginalFilename()),
                "signature", Base64.getEncoder().encodeToString(signatureBytes),
                "sha256", hash,
                "message", "Digital signature generated successfully."
        );
    }

    // Verifies the uploaded file against a signature and the sender's public key.
    @PostMapping(value = "/verify", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Map<String, Object> verifyFile(
            @RequestPart("file") MultipartFile file,
            @RequestParam("signature") String signatureText,
            @RequestParam("publicKey") String publicKeyText) throws Exception {

        if (file.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Please choose a file.");
        }

        byte[] publicKeyBytes = decodeBase64(publicKeyText, "public key");
        byte[] signatureBytes = decodeBase64(signatureText, "signature");
        PublicKey publicKey = KeyFactory.getInstance("RSA")
                .generatePublic(new X509EncodedKeySpec(publicKeyBytes));

        byte[] fileBytes = file.getBytes();

        Signature verifier = Signature.getInstance("SHA256withRSA");
        verifier.initVerify(publicKey);
        verifier.update(fileBytes);
        boolean valid = verifier.verify(signatureBytes);

        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        String hash = HexFormat.of().formatHex(digest.digest(fileBytes));

        return Map.of(
                "valid", valid,
                "sha256", hash,
                "fileName", safeFileName(file.getOriginalFilename()),
                "message", valid
                        ? "Signature is VALID. The file matches the signed document."
                        : "Signature is INVALID. The file or signature may have been changed."
        );
    }

    private byte[] decodeBase64(String value, String fieldName) {
        try {
            return Base64.getDecoder().decode(value.trim());
        } catch (IllegalArgumentException ex) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "Invalid Base64 " + fieldName + ".", ex);
        }
    }

    private String safeFileName(String name) {
        if (name == null || name.isBlank()) return "uploaded-file";
        return name.replaceAll("[\\\\/\\r\\n]", "_");
    }
}
